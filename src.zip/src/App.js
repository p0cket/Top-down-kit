// src/App.js
import React, { useState } from 'react';
import GameCanvas from './components/GameCanvas';
import Character from './components/Character';
import NPC from './components/NPC';
import Enemy from './components/Enemy';
import './index.css';

const App = () => {
  const walls = [
    { x: 300, y: 200, width: 50, height: 200 },
    { x: 500, y: 100, width: 200, height: 50 },
  ];

  const eventSquares = [
    { x: 150, y: 150, width: 50, height: 50, type: 'walk' },
    { x: 400, y: 400, width: 50, height: 50, type: 'activate' },
  ];

  const initialNPCs = [
    { initialPosition: { x: 200, y: 300 }, movementRange: { minX: 200, maxX: 300 }, walls },
    { initialPosition: { x: 400, y: 500 }, movementRange: { minX: 400, maxX: 500 }, walls },
  ];

  const [npcPositions, setNPCPositions] = useState(initialNPCs.map(npc => npc.initialPosition));
  const [playerPosition, setPlayerPosition] = useState({ x: 100, y: 100 });
  const [enemies, setEnemies] = useState([
    { id: 1, initialPosition: { x: 250, y: 250 }, initialHealth: 100 },
    { id: 2, initialPosition: { x: 450, y: 450 }, initialHealth: 100 },
  ]);

  const handleNPCPositionUpdate = (index, position) => {
    setNPCPositions(prevPositions => {
      const newPositions = [...prevPositions];
      newPositions[index] = position;
      return newPositions;
    });
  };

  const handlePlayerPositionUpdate = (position) => {
    setPlayerPosition(position);
  };

  // here is where the health is changed. But this is not the taking damage in the char.
  // so the damage is not displayed. Lets figure out how to get it displayed
  const handleEnemyHealthChange = (id, newHealth) => {
    setEnemies((prevEnemies) => {
      if (newHealth <= 0) {
        return prevEnemies.filter(enemy => enemy.id !== id);
      }
      return prevEnemies.map(enemy => enemy.id === id ? { ...enemy, initialHealth: newHealth } : enemy);
    });
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-2xl font-bold mb-4">Top-Down Game</h1>
      <div className="relative">
        <GameCanvas walls={walls} eventSquares={eventSquares} />
        <Character
          walls={walls}
          eventSquares={eventSquares}
          npcs={npcPositions}
          onPositionUpdate={handlePlayerPositionUpdate}
          enemies={enemies}
          onEnemyHealthChange={handleEnemyHealthChange}
        />
        {initialNPCs.map((npc, index) => (
          <NPC
            key={index}
            initialPosition={npc.initialPosition}
            movementRange={npc.movementRange}
            walls={walls}
            playerPosition={playerPosition}
            onPositionUpdate={(position) => handleNPCPositionUpdate(index, position)}
          />
        ))}
        {enemies.map(enemy => (
          <Enemy
            key={enemy.id}
            id={enemy.id}
            initialPosition={enemy.initialPosition}
            initialHealth={enemy.initialHealth}
            onHealthChange={handleEnemyHealthChange}
          />
        ))}
      </div>
    </div>
  );
};

export default App;